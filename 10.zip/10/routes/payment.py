
from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from models import db, Request

payment_bp = Blueprint('payment', __name__)

@payment_bp.route('/pay/<int:request_id>', methods=['GET', 'POST'])
@login_required
def pay_request(request_id):
    req = Request.query.get_or_404(request_id)
    if req.user_id != current_user.id:
        flash("Unauthorized payment attempt.")
        return redirect(url_for('user.dashboard'))

    if request.method == 'POST':
        network = request.form.get('network')
        phone = request.form.get('phone')
        flash(f"Payment prompt sent to {phone} on {network}. Confirm on your phone to complete.")
        req.status = "Payment Initiated"
        db.session.commit()
        return redirect(url_for('user.dashboard'))

    return render_template('payment.html', req=req)
