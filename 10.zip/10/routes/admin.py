
from flask import Blueprint, render_template, request, redirect, url_for
from models import db, Request, User

admin = Blueprint('admin', __name__)

@admin.route("/admin-dashboard")
def admin_dashboard():
    requests_data = Request.query.all()
    return render_template("admin_dashboard.html", requests=requests_data)

@admin.route("/update-request/<int:request_id>", methods=["POST"])
def update_request(request_id):
    req = Request.query.get_or_404(request_id)
    new_status = request.form.get("status")
    if new_status:
        req.status = new_status
        db.session.commit()
    return redirect(url_for('admin.admin_dashboard'))

@admin.route("/logout")
def logout():
    from flask import session
    session.clear()
    return redirect(url_for('auth.login'))
