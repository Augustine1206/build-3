
from flask import Blueprint, request, redirect, url_for, render_template, flash, session
from models import db, User
from otp_utils import generate_otp, send_otp_email, store_otp, validate_otp

verify_bp = Blueprint('verify', __name__)

@verify_bp.route('/send-otp/<email>')
def send_otp(email):
    otp = generate_otp()
    store_otp(email, otp)
    send_otp_email(email, otp)
    session['email_to_verify'] = email
    flash('OTP sent to your email.')
    return redirect(url_for('verify.verify_otp'))

@verify_bp.route('/verify-otp', methods=['GET', 'POST'])
def verify_otp():
    if request.method == 'POST':
        email = session.get('email_to_verify')
        otp_input = request.form.get('otp')
        if validate_otp(email, otp_input):
            user = User.query.filter_by(email=email).first()
            if user:
                user.role = user.role or 'user'
                db.session.commit()
                flash('Email verified! You can now log in.')
                return redirect(url_for('auth.login'))
            else:
                flash('No account found.')
        else:
            flash('Invalid OTP.')
    return render_template('verify_otp.html')
