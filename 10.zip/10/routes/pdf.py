
from flask import Blueprint, render_template, make_response
from flask_login import login_required, current_user
from models import db, Request
from xhtml2pdf import pisa
from io import BytesIO

pdf_bp = Blueprint('pdf', __name__)

def generate_pdf(html_content):
    pdf = BytesIO()
    pisa_status = pisa.CreatePDF(html_content, dest=pdf)
    if pisa_status.err:
        return None
    pdf.seek(0)
    return pdf

@pdf_bp.route('/download-pdf/<int:request_id>')
@login_required
def download_pdf(request_id):
    req = Request.query.get_or_404(request_id)
    if req.user_id != current_user.id and current_user.role != 'admin':
        return "Access Denied", 403

    html = render_template('pdf_template.html', req=req)
    pdf = generate_pdf(html)
    if not pdf:
        return "PDF generation failed", 500

    response = make_response(pdf.read())
    response.headers['Content-Type'] = 'application/pdf'
    response.headers['Content-Disposition'] = f'attachment; filename=request_{req.id}.pdf'
    return response
