
from flask import Blueprint, request, render_template, redirect, url_for, flash

payment_bp = Blueprint('payment', __name__)

@payment_bp.route('/pay', methods=['GET', 'POST'])
def handle_payment():
    if request.method == 'POST':
        amount = request.form.get('amount')
        print(f"Simulated payment of GHS {amount} received.")
        flash(f"Payment of GHS {amount} successful! Please confirm on your phone.")
        return redirect(url_for('payment_page'))
    return render_template('payment.html')

@payment_bp.route('/payment')
def payment_page():
    return render_template('payment.html')
